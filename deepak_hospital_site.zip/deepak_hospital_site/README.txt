
Deepak Hospital - Professional Landing Page (Bilingual)

Deploy on Vercel (no Git):
1) Go to vercel.com → New Project → "Deploy a Project without Git".
2) Upload this ZIP.
3) Project → Settings → Domains → add `deepakhospitals.in`.
4) GoDaddy DNS:
   - @  (A)      → 76.76.21.21
   - www (CNAME) → cname.vercel-dns.com
5) Wait for DNS to propagate.

To replace the map with exact location: put your Google Maps embed link in the iframe src.
